import Header from "./Utilites/Header";
import Footer from "./Utilites/Footer";
import { THEME, ThemeContext } from "Context/Theme";
import { useState } from "react";
import styles from "../styles/ShopHeader.module.css"

const ShopHome = () => {

    const [theme,setTheme] = useState(THEME.light)

    const handleTheme = () => {
          if (theme == THEME.light) {
              setTheme(THEME.dark)
              sessionStorage.setItem("theme","dark")
          } else {
              setTheme(THEME.light)
              sessionStorage.setItem("theme","light")
          }
        }
        
    return ( 
        <>
        <ThemeContext.Provider value={theme}>
        <Header handleTheme={handleTheme}/>
        <main>
            <div className={styles["Header-Container-full"]}>
                <div className={styles["Header-Container"]}>
                    <div className={styles["Header-Container-left"]}>
                        <div className={styles["Shop-Avatar"]}>
                        </div>
                        <div className={styles["Shop-Detail"]}>
                            <ul>
                                <li className={styles["Shop-head"]}>DOWINX STORE</li>
                                <li className={styles["Shop-data"]}></li>
                                <li className={styles["Shop-btn"]}></li>
                            </ul>
                        </div>
                    </div>
                    <div className={styles["Header-Container-right"]}>
                    
                    </div> 
                </div>
            </div>
        </main>
        <Footer/>

        </ThemeContext.Provider>
        


        
        
        
        </>


     );
}
 
export default ShopHome;