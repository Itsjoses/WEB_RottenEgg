import { THEME, ThemeContext } from "Context/Theme";
import { useState } from "react";
import Footer from "../Utilites/Footer";
import Header from "../Utilites/Header";
import styles from "../../styles/NewsLetter.module.css"

const NewsLetter = () => {
    const [theme,setTheme] = useState(THEME.light)
    const handleTheme = () => {
        if (theme == THEME.light) {
            setTheme(THEME.dark)
            sessionStorage.setItem("theme","dark")
        } else {
            setTheme(THEME.light)
            sessionStorage.setItem("theme","light")
        }
      }
    return ( 
        <ThemeContext.Provider value={theme}>
            <Header handleTheme={handleTheme}/>
                <div className={styles["LetterContainer"]}>
                    <div className={styles["Container"]}>
                        <div className={styles["form-Container"]}>
                        <form action="">
                            <div className={styles["Subject"]}>
                                <input type="text" placeholder="Add a Subject"/>
                            </div>  
                            <div className={styles["Letter"]}>
                                <textarea name="" id="">

                                </textarea>
                            </div> 
                        </form>
                        
                        </div>
                        <div className={styles["form-button-Container"]}>
                        <button className={styles["Submit-Letter"]}>Submit</button>  
                        </div>
                        
                    </div>  
                </div>  
            <Footer/>
        </ThemeContext.Provider>


     );
}
 
export default NewsLetter;