import { ApolloClient } from "@apollo/client";
import { InMemoryCache } from "@apollo/client/cache";
import { gql } from "@apollo/client/core";
import Testing from "./Testing";
import styles from "../styles/test.module.css"
const Test = () => {

    return ( 
            <div className={styles.testing}>

            </div>
     );
}
 
export default Test;